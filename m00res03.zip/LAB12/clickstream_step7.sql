CREATE OR REPLACE FUNCTION window_exclusion(clickstream_state, clickstream_state)
RETURNS clickstream_state AS $$ 
BEGIN
    RAISE EXCEPTION 'aggregate may only be called from a window function';
END;
$$ LANGUAGE PLPGSQL STRICT;
