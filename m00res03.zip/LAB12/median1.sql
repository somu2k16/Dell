SELECT 
  ( arr[ length/2 + 1 ] + arr[ (length + 1)/2 ] ) / 2.0 AS median_income 
FROM(
  SELECT 
    array_agg(hinc ORDER BY hinc) AS arr
  , count(*) AS length 
  FROM 
    housing
 ) AS q
;