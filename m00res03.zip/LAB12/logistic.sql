DROP TABLE IF EXISTS logr_coef;
CREATE TABLE logr_coef AS
SELECT 0::INT AS bla, NULL::FLOAT8[] AS coef
DISTRIBUTED BY (bla); 
UPDATE logr_coef SET coef = (SELECT coef FROM madlib.logregr('artificiallogreg', 'y', 'x', 20, 'irls', 0.001) AS coef);

\a 
\o  graphics.txt
SELECT DISTINCT rank::FLOAT8/total_count AS x, count::FLOAT8/total_true AS y
FROM (
    SELECT
        y,
        rank() OVER (ORDER BY prediction DESC),
        count(*) OVER () total_count,
        count(*) FILTER (WHERE y = TRUE) OVER (ORDER BY prediction DESC),
        count(*) FILTER (WHERE y = TRUE) OVER () AS total_true
    FROM (
        SELECT r.*, 1. / (1. + exp(-dotProduct(r.x, c.coef))) AS prediction
        FROM artificiallogreg AS r
             CROSS JOIN
           logr_coef as c
    ) q
) p;
\o
