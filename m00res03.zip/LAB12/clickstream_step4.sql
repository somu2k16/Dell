SELECT sid from
(
    SELECT sid, page_type, time,
        clickpath(
            upper(substring(page_type for 1)),
            '^SAH+B'
        ) OVER (prefix) AS match,
        count(*) OVER (prefix) AS seq_length,
        count(*) OVER (PARTITION BY sid) AS max_seq_length
    FROM clicks
    WINDOW prefix AS (PARTITION BY sid ORDER BY time ASC)
) AS subq
WHERE seq_length = max_seq_length AND match = true;
