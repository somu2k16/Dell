SELECT 
    f.name,  ( arr[ length/2 + 1 ] + arr[ (length + 1)/2 ] ) / 2.0 AS median_income FROM
    (SELECT state AS s, array_agg(hinc ORDER BY hinc) AS arr, count(*) AS length 
     FROM housing 
     GROUP BY state
     ) AS q
JOIN
   fips f
ON
   s = f.code

ORDER BY
    f.name;

 



