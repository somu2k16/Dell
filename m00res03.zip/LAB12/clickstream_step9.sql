CREATE OR REPLACE FUNCTION clickpath_transition(
    state clickstream_state, symbol CHAR(1), pattern VARCHAR)
RETURNS clickstream_state AS $$
    SELECT CASE
        WHEN $1 IS NULL THEN ($2, $3)::clickstream_state
        ELSE ($1.sequence || $2, $3)::clickstream_state
    END;
$$ LANGUAGE SQL CALLED ON NULL INPUT;
