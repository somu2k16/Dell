CREATE OR REPLACE FUNCTION clickpath_final(state clickstream_state)
RETURNS BOOLEAN AS $$
    SELECT $1.sequence ~ $1.pattern;
$$ LANGUAGE SQL STRICT;
