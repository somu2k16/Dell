DROP AGGREGATE IF EXISTS clickpath(/* Symbol */ CHAR, /* regex */ TEXT);
CREATE AGGREGATE clickpath(/* Symbol */ CHAR, /* regex */ TEXT) (
    STYPE = clickstream_state, 
    SFUNC = clickpath_transition,
    FINALFUNC = clickpath_final,
    PREFUNC = window_exclusion
);
