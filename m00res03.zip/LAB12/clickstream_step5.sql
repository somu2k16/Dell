DROP TYPE IF EXISTS clickstream_state CASCADE;
CREATE TYPE clickstream_state AS (
    sequence VARCHAR,
    pattern VARCHAR
);
