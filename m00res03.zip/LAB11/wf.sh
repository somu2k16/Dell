#!/bin/sh

# wordfreq.sh 
# feed the filename into tr that converts punctuations into spaces
# then changes a single space to a newline, converts upper to lower case
# sorts the output, runs it through uniq -c to count occurences 
# and the reverse sorts it to get the highest frequency words
# from "Shell Books" available at books.google.com

fs="-"
fs=${1:+"$@"}			# check this syntax


#
# if this were a MapReduce job, the first 3 invocations of tr
# would represent out mapping function 
# and the reduce function would be represented by the uniq function 
# the 1st sort function is provided by the Hadoop framework
# the last sort and sed commands simply organize the frequency count
# in descending order
# 

cat $fs \
| tr '[:punct:]' ' ' \
| tr -s ' ' '\012' \
| tr [A-Z] [a-z] \
| sort \
| uniq -c \
| sort -nr 



