#!/bin/sh 

# hadoop script that implements the WordCount program

HSTREAMING="hadoop jar $HADOOP_HOME/contrib/streaming/hadoop-*-streaming.jar"

$HSTREAMING  \
-input input/speech.txt \
-output output/d$$ \
-mapper "./mapper.sh" \
-reducer "reducer.sh" \
-file `pwd`/mapper.sh \
-file `pwd`/reducer.sh


