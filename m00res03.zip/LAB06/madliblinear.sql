DROP TABLE IF EXISTS zeta1;
CREATE TABLE zeta1 (
     depvar FLOAT8,
     indepvar FLOAT8[] 
) DISTRIBUTED BY (depvar);
     
INSERT INTO zeta1(
           depvar,indepvar[1],indepvar[2],indepvar[3],indepvar[4])
SELECT
    ln(meanhouseholdincome + 1),
    1,
    CASE WHEN sex = 'M'  THEN 0
            WHEN sex = 'F' THEN 1
         END AS  sex,
     meanage,
     meanemployment
FROM
     zeta;


SET SEARCH_PATH to madlib,public,myschema;
SELECT (linregr(depvar,indepvar)).r2 FROM zeta1;
SELECT (linregr(depvar,indepvar)).coef FROM zeta1;
SELECT (linregr(depvar,indepvar)).std_err FROM zeta1;
SELECT (linregr(depvar,indepvar)).t_stats FROM zeta1;
SELECT (linregr(depvar,indepvar)).p_values FROM zeta1;

